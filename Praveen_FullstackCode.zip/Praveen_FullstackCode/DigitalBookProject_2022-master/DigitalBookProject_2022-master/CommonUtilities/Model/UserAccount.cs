﻿namespace CommonUtilities.Model
{
    public class UserAccount
    {
        public string UserName { get; set; } = null!;
        public string Email { get; set; } = null!;
        public string UserPass { get; set; } = null!;
        public string UserRole { get; set; } = null!;
    }
}
