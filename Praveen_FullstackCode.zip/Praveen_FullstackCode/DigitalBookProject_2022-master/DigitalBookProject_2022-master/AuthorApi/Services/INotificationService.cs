﻿using CommonUtilities.Model;
using CommonUtilities.DataEntity;

namespace AuthorApi.Services
{
    public interface INotificationService
    {
        DigitalBooks2022Context dbContext { get; set; }

        //List<string>? sendNotification();
    }
}