﻿using CommonUtilities.Model;
using CommonUtilities.DataEntity;

namespace AuthorApi.Services
{
    public class NotificationService : INotificationService
    {
        public DigitalBooks2022Context dbContext { get; set; }

        public NotificationService(DigitalBooks2022Context bookDatabaseContext)
        {
            dbContext = bookDatabaseContext;
        }

    }
}
