export interface Users {
    userId:number
    userName: string
    email: string
    userPass: string
    userRole: string
}