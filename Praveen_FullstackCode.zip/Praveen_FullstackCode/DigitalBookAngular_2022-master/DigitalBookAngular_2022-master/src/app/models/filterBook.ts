export interface FilterBook {
    authorName : string
    price : number
    category : string   
}