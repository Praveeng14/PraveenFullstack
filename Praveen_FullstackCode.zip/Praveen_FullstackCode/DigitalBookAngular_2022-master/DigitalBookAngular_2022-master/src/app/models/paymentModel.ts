export interface PaymentDetails {
    paymentId : Number
    buyerEmailId : string
    buyerName: string
    bookName: string
    paymentDate: Date
}