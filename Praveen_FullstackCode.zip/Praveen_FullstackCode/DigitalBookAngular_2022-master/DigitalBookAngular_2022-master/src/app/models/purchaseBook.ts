export interface BuyBook {
    buyerName : string
    emailID : string
    bookName : string 
}